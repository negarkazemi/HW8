#include <stdio.h>
#include <string.h>
#include <ctype.h> 
int main ()
{
    int n;
    char space[16];

    printf("enter the number of your words\n");
    scanf("%d",&n);

    printf("enter your words & a synonym for that after 3 space\n");
    char word1[n][20],word2[n][20];
    for (int i=0; i<n; i++)
        scanf("%s   %s", &word1[i], &word2[i]);

    char sentence[100];
    printf("enter a sentence with first words\n");

    gets(space);
    fgets (sentence, 100, stdin);


    for (int i=0; i<=100; i++)
        sentence[i]=tolower(sentence[i]);
    int wordsize;
    char check[100];
    for (int i=0; i<=100; i+wordsize)
        for (int j=0; j<n; j++)
        {   
            int flag=1;
            for(int k=0; k<strlen(word1[j]); k++)
                check[i]=sentence[i];
            for(int z=0; z<strlen(word1[j]); z++)
                if (check[z]!=word1[j][z])
                    flag=0;
            if(flag==1)
            {
                wordsize=strlen(word1[j])+1;
                if (strlen(word1[j])>strlen(word2[j]))
                    printf("%s ",word2[j]);
                else 
                    printf("%s ",word1[j]);


            }
        }

return 0;
}

