//Negar Kazemi 40223064

#include <stdio.h>
#include <stdlib.h>
struct time
{
    int min;
    int sec;
};

struct runner
{
    char FirstName [10];
    char LastName [10];
    int ID;
    struct time *Record;
    struct time RunningTime;
    
};


int main ()
{
    int n;
    printf ("enter the number of players\n");
    scanf ("%d",&n);
    struct runner player[n];

    for(int i=0; i<n; i++)
        player[i].Record= (struct time*)malloc(sizeof(struct time));

    for (int i=0; i<n; i++)
    {
        printf("player %d:\n", i+1);
        printf("first name\n");
        scanf("%s",&player[i].FirstName);
        printf("last name\n");
        scanf("%s",&player[i].LastName);
        printf("ID\n");
        scanf("%d",&player[i].ID);
        printf("best record (minute and second)\n");
        scanf("%d",&player[i].Record->min);
        scanf("%d",&player[i].Record->sec);
        printf("running time (minute and second)\n");
        scanf("%d",&player[i].RunningTime.min);
        scanf("%d",&player[i].RunningTime.sec);       
    }

    int time[n];
    int rec[n];
    int j;
    for (j=0; j<n; j++)
    {
       time[j]=(player[j].RunningTime.min)*60+(player[j].RunningTime.sec);
       rec[j]=(player[j].Record->min)*60+(player[j].Record->sec);
       
    }

    int b;
    for(int k=0; k<n; k++)
    {
        if(time[k]>time[k+1])
        {
            b=time[k];
            time[k]=time[k+1];
            time[k+1]=b;
        }
    }

    int c;
    for(int k=0; k<n; k++)
    {
        if(rec[k]>rec[k+1])
        {
            c=rec[k];
            rec[k]=rec[k+1];
            rec[k+1]=c;
        }    


    }
    for (int i=0; i<n; i++)
        {
            if(time[0]==(player[i].RunningTime.min)*60+(player[i].RunningTime.sec))
            {
                printf("winner: %s %s\n", player[i].FirstName, player[i].LastName);
                if((player[i].Record->min)*60+(player[i].Record->sec)>time[0])
                    printf("winner broke her/his record\n");
                else
                    printf("winner didn't break her/his record\n");
            }
        }


    if (rec[0]>time[0])
        printf("winner broke best record\n");
    else
        printf("winner didn't break best record\n");



    printf("First Name    Last Name     ID         runinng time(min&sec)    record(min&sec)\n");
    for (int k=0; k<n; k++)
    {
        for (int i=0; i<n; i++)
        {
            if(time[k]==(player[i].RunningTime.min)*60+(player[i].RunningTime.sec))
                printf("%-14s%-14s%-11d%-12d%-13d%-12d%d\n",player[i].FirstName, player[i].LastName, player[i].ID, player[i].RunningTime.min, player[i].RunningTime.sec, player[i].Record->min, player[i].Record->sec);
        }
        
    }


    for (int i=0; i<n; i++)  
        free(player[i].Record);
    
    return 0;

}



    